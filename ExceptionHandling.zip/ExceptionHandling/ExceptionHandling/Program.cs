﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class StackException : Exception
    {
        public StackException(string message) : base(message)
        {
            //messeage already created in throw statement
        }
    }

    class Mystack : ICloneable
    { 
        public int size { get; set; }
        protected int top;
        protected int[] array;

        public Mystack(int Size)
        { 
            this.size= Size;
            array = new int[Size];
            top = 0;
        }
        public void push(int value)
        {
            if (!(top < size - 1))
            {
                throw new StackException("Stack is full...");
            }
            this.array[this.top]= value;
        }
        public void pop()
        {
            if (!(top > 0))
            {
                throw new StackException("Stack is Empty....");   
            }
            top--;
        }
        public void display()
        {
            for (int i = 0; i < top; i++)
            {
                Console.WriteLine(array[i]);
            }
        }
      public object Clone()
        {
            return this.MemberwiseClone();
        }
    }   

     class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter the array size...");
                int size = Convert.ToInt32(Console.ReadLine());
                Mystack mystack = new Mystack(size);
                var clone = (Mystack)mystack.Clone();
                Console.WriteLine("Enter the values....");
                for (int i = 0; i < size; i++)
                {
                    int b = Convert.ToInt32(Console.ReadLine());
                    clone.push(b);
                }
            }
            catch (StackException se)
            {
                Console.WriteLine(se.Message);
            }
            Console.ReadKey();
        }
    }
}
