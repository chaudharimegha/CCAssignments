﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigment1
{
    struct book
    {
        public int BookId;
        public string BookType;
        public string BookTitle;
        public int BookPrice;  
    }

     class BookStructure
    {
        public static void Main()
        {
            int noBook = 3;
            book[] books = new book[noBook];

            for (int i = 0; i < noBook; i++)
            {
                Console.WriteLine("Book information========>");
                Console.WriteLine("Enter the book ID-->");
                books[i].BookId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the book Type-->");
                books[i].BookType = Console.ReadLine();

                Console.WriteLine("Enter the book Title--->");
                books[i].BookTitle = Console.ReadLine();
                Console.WriteLine("Enter the book price--->");
                books[i].BookPrice = Convert.ToInt32(Console.ReadLine());
               

            }
            Console.ReadKey();

        }
    }
}
