﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigment1
{
    class ParamArray
    {
        public static int Sum(params int[] arr)
        {
            int total = 0;

            for (int i = 0; i <arr.Length; i++)
            {
                total = total + arr[i];
            }
            return total;
        }

        public static void Main()
        {
            int[] arr = new int[5];
            Console.WriteLine("Enter the array --->");
            for (int j = 0; j < arr.Length; j++)
            {
                arr[j] = Convert.ToInt32(Console.ReadLine());  
            }
            int sum = Sum(arr);
            Console.WriteLine("sum of array is--->" + sum);
            Console.ReadKey();
        }

    }
}
