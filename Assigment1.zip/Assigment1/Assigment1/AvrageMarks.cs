﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigment1
{
     class AvrageMarks
    {
        public static void Main()
        {
            int max;
            Console.WriteLine("Enter the marks of student 1--->");
            int stuMark1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the marks of student 2--->");
            int stuMark2=Convert.ToInt32((Console.ReadLine()));
            Console.WriteLine("Enter the marks of student 3--->");
            int stuMark3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the marks of student 4--->");
            int stuMark4 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the marks of student 5--->");
            int stuMark5 = Convert.ToInt32(Console.ReadLine());

            if (stuMark1 > stuMark2 && stuMark1 > stuMark3 && stuMark1 > stuMark4 && stuMark1 > stuMark5)
            {
                max = stuMark1;
            }
            else if (stuMark2 > stuMark1 && stuMark2 > stuMark3 && stuMark2 > stuMark4 && stuMark2 > stuMark5)
            {
                max = stuMark2;
            }
            else if(stuMark3 > stuMark1 && stuMark3 > stuMark2 && stuMark3 > stuMark4 && stuMark3 > stuMark5)
            {
                max = stuMark3;
            }
            else if (stuMark4 > stuMark1 && stuMark4 > stuMark2 && stuMark4 > stuMark3 && stuMark4 > stuMark5)
            {
                max = stuMark4;
            }
            else 
            {
                max = stuMark5;
            }
            Console.WriteLine("Avarage marks from 5  student is===>" + max);
            Console.ReadKey();
        }

    }
}
