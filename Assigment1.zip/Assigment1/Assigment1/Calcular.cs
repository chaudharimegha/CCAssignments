﻿using System;

namespace Assigment1
{
    class Calcular
    {
        static void Main(string[] args)
        {
            Console.WriteLine("**********calculater************");
            Console.WriteLine("\n");

           
            Console.WriteLine("1.Addtion");
            Console.WriteLine("2.Substration");
            Console.WriteLine("3.multiplication");
            Console.WriteLine("4.Division");

            Console.WriteLine("Enter your choice----->");

            int a, b, result;

            int ch =Int32.Parse(Console.ReadLine());
            switch (ch)
            {
                case 1:
                    Console.WriteLine("Enter the value A--->");
                    a = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the value B--->");
                    b = Int32.Parse(Console.ReadLine());
                    result = a + b;
                    Console.WriteLine("Result of Addtion is =====>"+result);
                    break;

                case 2:
                    Console.WriteLine("Enter the value A--->");
                    a = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the value B--->");
                    b = Int32.Parse(Console.ReadLine());
                    result = a - b;
                    Console.WriteLine("Result of Subtration is =====>" + result);
                    break;

                case 3:
                    Console.WriteLine("Enter the value A--->");
                    a = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the value B--->");
                    b = Int32.Parse(Console.ReadLine());
                    result = a * b;
                    Console.WriteLine("Result of Multiplication is =====>" + result);
                    break;

                case 4:
                    Console.WriteLine("Enter the value A--->");
                    a = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the value B--->");
                    b = Int32.Parse(Console.ReadLine());
                    result = a / b;
                    Console.WriteLine("Result of division is =====>" + result);
                    break;

                default:
                    Console.WriteLine("Invalid choice....");
                    break;
            }
            Console.ReadKey();
        }
    }
}
