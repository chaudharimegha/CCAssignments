﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigment1
{
     class SwapTwono
    {
        public static void swapno(ref int num1, ref int num2)
        {
            int temp;

            temp = num1;
            num1 = num2;
            num2 = temp;

            Console.WriteLine("After swapping the numberm num1-->" + num1+" " + "num2-->" + num2);

        }
        public static void Main()
        {
            Console.WriteLine("Enter the number 1--->");
            int  num1 = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Enter the number2---->");
            int num2 = Int32.Parse(Console.ReadLine());
            swapno(ref num1, ref num2);
            Console.ReadKey();
            
        }
       
        
    }
}
