﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigment1
{
     class AreaOfCircle
    {
        const float PI = 3.1415927F;

        public void areacircumfarance(Double radius)
        { 
            double area = PI*radius*radius;
            Console.WriteLine("Area of circle ---->"+area);
            double circumfarace = 2*PI*radius;
            Console.WriteLine("Circumfarance ----->" + circumfarace);
        }
        public static void Main()
        {
            Console.WriteLine("Enter the radius of circle--->");
            int radius = Int32.Parse(Console.ReadLine());
            AreaOfCircle area = new AreaOfCircle();
            area.areacircumfarance(radius);
            Console.ReadKey();
        }
    }
}
