﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_and_Polymorphisum
{

    interface IPritable
    {
        void PrintDetails();
    }
    public class Employee :IPritable
    {
        public double HRA;
        public double TA;
        public double DA;
        public double PF;
        public double TDS;
        public double NetSalary;
        public double GrossSalary;

        public int EmpId { get; set; }
        public string Empname { get; set; }
        public double Empsalary { get; set; }


        public Employee(int empid, string empname, double empsalary)
        {
            this.EmpId = empid;
            this.Empname = empname;
            this.Empsalary = empsalary;

            if (empsalary < 5000)
            {
                HRA = (empsalary * 10) / 100;
                TA = (empsalary * 5) / 100;
                DA = (empsalary * 15) / 100;
            }
            else if (empsalary < 10000)
            {
                HRA = (empsalary * 15) / 100;
                TA = (empsalary * 10) / 100;
                DA = (empsalary * 20) / 100;

            }
            else if (empsalary < 15000)
            {
                HRA = (empsalary * 20) / 100;
                TA = (empsalary * 15) / 100;
                DA = (empsalary * 25) / 100;
            }
            else if (empsalary < 20000)
            {
                HRA = (empsalary * 25) / 100;
                TA = (empsalary * 20) / 100;
                DA = (empsalary * 30) / 100;
            }
            else
            {
                HRA = (empsalary * 30) / 100;
                TA = (empsalary * 25) / 100;
                DA = (empsalary * 35) / 100;
            }
            GrossSalary = empsalary + HRA + TA + DA;

        }
        public virtual void calculateSalary()
        {
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF + TDS);
        }
        public void PrintDetails()
        {
            Console.WriteLine("Name of Employee--->" + Empname);
            Console.WriteLine("Employee ID ------->" + EmpId);
            Console.WriteLine("Employee salary---->" + Empsalary);
            Console.WriteLine("Gross Salary of  Employee -->" + GrossSalary);
        }
}
     public class Manager : Employee
    {
        public Manager(int empid, string empname, double empsalary) :base(empid,empname,empsalary)
        {
            double PA = (empsalary * 8) / 100;
            double FA = (empsalary * 13) / 100;
            double OA = (empsalary * 3) / 100;
            Double grossSalary = empsalary + PA + FA + OA;
            Console.WriteLine("Gross Salary of Manager -->" + grossSalary);
        }

        public override void calculateSalary()
        {
            base.calculateSalary();
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF + TDS);
           

        }
    }
    class MarketingExecetive : Manager
    {
        public MarketingExecetive(int eid, string ename, double empsalary) : base(eid, ename, empsalary)
        {

            int kilometer = 10;
            int telephone = 1000;
            int tour = kilometer * 5;
            Double grossSalary = empsalary + kilometer + telephone + tour;

            Console.WriteLine("Gross Salary of   MarketingExecutive-->" + grossSalary);
        }
        public override void calculateSalary()
        {
            base.calculateSalary();
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF + TDS);

            Console.WriteLine("Net Salary of MarketingExecutive-->" + NetSalary);

        }
    }
    class EmployeeManegaer
        {
                public static void Main(string[] args)
                {
                     Employee e = new Employee(12, "Megha", 7000);
                     //Manager M = new Manager(12, "Megha", 7000);
                    
                    //e.calculateSalary();
                    e.PrintDetails();
                    MarketingExecetive ME = new MarketingExecetive(12, "Megha", 7000);
                         //M.calculateSalary();
                    ME.calculateSalary();

                     Console.ReadKey();

        }
    }
    }

