﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance_and_Polymorphisum
{

    class MyStack : ICloneable
    {
        public int size { get; set; }
        protected int top;
        protected int[] array;

        public MyStack(int size)
        {
            this.size = size;
            array = new int[this.size];
            top = 0;
        }

        public void Push(int value)
        {
            this.array[this.top] = value;
            top++;
        }

        public void Pop()
        {
            top--;
        }

        public void Display()
        {
            for (int i = 0; i < top; i++)
            {
                Console.WriteLine(array[i]);
            }
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }

     class StackProgram
    {
        public static void Main()
        {
            Console.WriteLine("Enter array Size:");
            int size = Convert.ToInt32(Console.ReadLine());
            MyStack stack = new MyStack(size);
            var clone = (MyStack)stack.Clone();
            Console.WriteLine("Enter values :");
            for (var i = 0; i < size; i++)
            {
                int b = Convert.ToInt32(Console.ReadLine());
                clone.Push(b);
            }
            Console.WriteLine("After Push-->");
            clone.Display();
            clone.Pop();
            Console.WriteLine("After Popping-->");
            clone.Display();
            Console.ReadKey();
        }
    }

}
