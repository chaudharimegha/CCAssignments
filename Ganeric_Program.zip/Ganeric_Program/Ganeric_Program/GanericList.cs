﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ganeric_Program
{
    class Employee
    { 
        public int Id { get; set; } 
        public string Name { get; set; }    
        public double salary { get; set; }
    }
     class GanericList
    {
        public static void Main()
        {
            List<Employee> emplist = new List<Employee>();
            
            Employee emp1 = new Employee()
            {
                Id = 1,
                Name = "Megha",
                salary =10000
            };

            Employee emp2 = new Employee()
            {
                Id=2,
                Name="Sara",
                salary=7000
            };
            Employee emp3 = new Employee()
            {
                Id=3,
                Name="Sita",
               salary=8000,
            };
            emplist.Add(emp1);
            emplist.Add(emp2);
            emplist.Add(emp3);
            foreach (Employee e in emplist)
            {
                Console.WriteLine(e.Id + "" + e.Name + "" + e.salary);
                
            }
            Console.WriteLine("Total number of employee-->"+emplist.Count);
            Console.ReadKey();
        }
    }
}
