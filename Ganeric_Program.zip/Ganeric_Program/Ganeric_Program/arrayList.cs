﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ganeric_Program
{
    class Emp
    {
        public int EmpID;
        public string EmpName;
        public double EmpSalary;
    }
     class arrayList
    {
        public static void Main()
        {
            ArrayList a = new ArrayList();
            Emp e = new Emp();
            Console.WriteLine("Enter the Employee ID--->");
            e.EmpID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Employee Name-->");
            e.EmpName = Console.ReadLine();
            Console.WriteLine("Enter the Employee Salary-->");
            e.EmpSalary = Convert.ToDouble(Console.ReadLine());
            a.Add(e);
            foreach (Emp emp in a)
            {
                Console.WriteLine(emp.EmpID + " " + emp.EmpName + "" + emp.EmpSalary);
            }
            Console.ReadKey();
        }
    }
}
