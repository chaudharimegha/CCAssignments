﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ganeric_Program
{
    class ArrayOpeartion
    {
        public void printArray(int[] intergerArray)
        {
            foreach (var item in intergerArray)
            {
                Console.WriteLine("Array Elements -->" + item);
            }
        }

        public void printArray(string[] stringArray)
        {
            foreach (var item in stringArray)
            {
                Console.WriteLine("String Array Elements-->" + item);
            }
        }
    }
     class Program
    {
        static void Main(string[] args)
        {
            int[]integerArray =new int[5];
            int[] integerArray1 = new int[5];
            string[]stringArray = new string[5];
            string[] stringArray1 = new string[5];

            Console.WriteLine("Enter the Array elements--->");
            for (int i = 0; i < integerArray.Length; i++)
            { 
                    integerArray[i] =Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("Enter the string array---->");
            for (int i = 0; i < stringArray.Length; i++)
            {
                stringArray[i] = Console.ReadLine();
            }
            ArrayOpeartion array = new ArrayOpeartion();
            Console.WriteLine("Array List are--->");
            array.printArray(integerArray);
            Console.WriteLine();

            Console.WriteLine("\n String elements-->");
            array.printArray(stringArray);
            Console.WriteLine();

            //Revesering array
            Array.Reverse(integerArray);
            Console.WriteLine("After Reserving --->");
            array.printArray(integerArray);
            Console.WriteLine();

            //Sorting Array
            Array.Sort(integerArray);
            Console.WriteLine("After Sorting--->");
            array.printArray(integerArray);
            Console.WriteLine();

            //copy the Array
            Array.Copy(integerArray, integerArray1, 5);
            Console.WriteLine("After Copy the Array-->");
            array.printArray(integerArray);
            Console.WriteLine();

            //Revesering array
            Array.Reverse(stringArray);
            Console.WriteLine("After Reserving string Array --->");
            array.printArray(stringArray);
            Console.WriteLine();

            //Sorting Array
            Array.Sort(stringArray);
            Console.WriteLine("After Sorting string Array--->");
            array.printArray(stringArray);
            Console.WriteLine();

            //copy the Array
            Array.Copy(stringArray, stringArray1, 5);
            Console.WriteLine("After Copy the Array-->");
            array.printArray(stringArray);
            Console.WriteLine();

            Console.ReadKey();
        }
        
    }
}
