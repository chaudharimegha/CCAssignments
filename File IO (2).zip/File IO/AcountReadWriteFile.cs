﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.IO;
namespace Inheritance_and_Polymorphism
{

    class EmpAccount
    {
        public int Account_NO { get; set; }
        public string Name { get; set; }
        public int salary { get; set; }
    }
    class AcountReadWriteFile
    {

        public static void Main()
        {
            ArrayList e1 = new ArrayList()
            {
                new EmpAccount { Account_NO = 101, Name = "Megha", salary = 1000 },
                new EmpAccount { Account_NO = 102, Name = "Megha1", salary = 11000 },
                new EmpAccount { Account_NO = 103, Name = "Megha2", salary = 41000 },

            };

            try
            {
                using (StreamWriter sw = new StreamWriter(@"D:\C#\AccountFile.txt"))
                {

                    foreach (EmpAccount i in e1)
                    {
                        sw.WriteLine("ID-->" + " " + i.Account_NO + " " + "Name-->" + " " + i.Name + " " + "Salary-->" + " " + i.salary);
                    }

                }
                // Read and show each line from the file.
                string line = "";
                using (StreamReader sr = new StreamReader(@"D:\C#\AccountFile.txt"))
                {
                    while ((line = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(line);
                    }
                }

            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
            }
        
    }

}