﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
namespace Inheritance_and_Polymorphism
{
    [Serializable]
    class SerializedEmpDetails
    {
        //public int ID;
       // public String Name;
       // public double salary;

        public int ID { get; set; }
        public string Name { get; set; }
        public double salary { get; set; }

        public SerializedEmpDetails(int id,string name,double Salary )
        {
            this.ID = id;
            this.Name = name;
            this.salary = Salary;
        }
        public static void Main()
        {
            SerializedEmpDetails S = new SerializedEmpDetails(12,"Megha",7000);

            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream(@"D:\C#\EMPserizationFile.txt", FileMode.Create, FileAccess.Write);


            formatter.Serialize(stream, S);
            stream.Close();

            stream = new FileStream(@"D:\C#\EMPserizationFile.txt", FileMode.Open, FileAccess.Read);
            SerializedEmpDetails objnew = (SerializedEmpDetails)formatter.Deserialize(stream);

            Console.WriteLine(objnew.ID);
            Console.WriteLine(objnew.Name);
            Console.WriteLine(objnew.salary);
            Console.ReadKey();

        }

    }
}
