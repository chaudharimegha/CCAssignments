﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerializedEmpManager
{
    [Serializable]
    public class EMP
    {


        public double HRA;
        public double TA;
        public double DA;
        public double PF;
        public double TDS;
        public double NetSalary;
        public double GrossSalary;
        public int EmpNo { get; set; }
        public string EmpName { get; set; }
        public double EmpSalary { get; set; }

        public EMP(int eid, string ename, double empsalary)
        {
            this.EmpNo = eid;
            this.EmpName = ename;
            this.EmpSalary = empsalary;


            if (empsalary < 5000)
            {
                HRA = (empsalary * 10) / 100;
                TA = (empsalary * 5) / 100;
                DA = (empsalary * 15) / 100;
            }
            else if (empsalary < 10000)
            {
                HRA = (empsalary * 15) / 100;
                TA = (empsalary * 10) / 100;
                DA = (empsalary * 20) / 100;

            }
            else if (EmpSalary < 15000)
            {
                HRA = (empsalary * 20) / 100;
                TA = (empsalary * 15) / 100;
                DA = (empsalary * 25) / 100;
            }
            else if (EmpSalary < 20000)
            {
                HRA = (empsalary * 25) / 100;
                TA = (empsalary * 20) / 100;
                DA = (empsalary * 30) / 100;
            }
            else
            {
                HRA = (empsalary * 30) / 100;
                TA = (empsalary * 25) / 100;
                DA = (empsalary * 35) / 100;
            }

            Console.WriteLine("Name of Empoyee--->" + EmpName);
            Console.WriteLine("EMP_NO of Empoyee--->" + EmpNo);
            GrossSalary = empsalary + HRA + TA + DA;
            Console.WriteLine("Gross Salary of  Employee -->" + GrossSalary);
        }

        public virtual void CalculateSalary()
        {

            //PF = (GrossSalary * 10) / 100;
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF + TDS);
            //Console.WriteLine("Net Salary of Employee --->" + NetSalary);

        }


    }
    public class Manager : EMP
    {
        public Manager(int eid, string ename, double empsalary) : base(eid, ename, empsalary)
        {

            double PA = (empsalary * 8) / 100;
            double FA = (empsalary * 13) / 100;
            double OA = (empsalary * 3) / 100;
            Double grossSalary = empsalary + PA + FA + OA;
            Console.WriteLine("Gross Salary of Manager -->" + grossSalary);

        }
        public override void CalculateSalary()
        {
            base.CalculateSalary();
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF + TDS);

        }


    }
    class MarketingExecetive : Manager
    {
        public MarketingExecetive(int eid, string ename, double empsalary) : base(eid, ename, empsalary)
        {

            int kilometer = 10;
            int telephone = 1000;
            int tour = kilometer * 5;
            Double grossSalary = empsalary + kilometer + telephone + tour;

            Console.WriteLine("Gross Salary of   MarketingExecutive-->" + grossSalary);
        }
        public override void CalculateSalary()
        {
            base.CalculateSalary();
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF + TDS);

            Console.WriteLine("Net Salary of MarketingExecutive-->" + NetSalary);

        }
    }

}
