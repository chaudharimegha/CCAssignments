﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerializedEmpManager
{
    class FileIO
    {
        // StreamReader ReadFile = null;
        public static void Main()
        {
            string file = @"D:\C#\EmployeeDetails.txt";
            StreamReader ReadFile = new StreamReader(file);
            try
            {
                if (File.Exists(file))
                {
                    //StreamReader ReadFile = new StreamReader  .1p(file);
                    String readline;
                    while ((readline = ReadFile.ReadLine()) != null)
                    {
                        Console.WriteLine(readline);
                    }
                    //  Console.WriteLine("\n");
                }
                DirectoryInfo di = new DirectoryInfo("D:\\");
                DirectoryInfo[] diArr = di.GetDirectories();
                foreach (DirectoryInfo dri in diArr)
                    Console.WriteLine(dri.Name);
            }
            catch (FileNotFoundException Ex)
            {
                Console.WriteLine(Ex.Message);
            }
            finally
            {
                ReadFile.Close();
            }
            Console.ReadKey();
        }

    }
}
